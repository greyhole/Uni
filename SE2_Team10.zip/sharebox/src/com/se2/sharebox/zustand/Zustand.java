package com.se2.sharebox.zustand;

/**
 * gibt Nutzername und Ort wieder
 * 
 * @author wiesel
 * @verion 1.0
 */
public class Zustand {

	private boolean active;
	private String email;
	private String dir;

	/**
	 * default constructor
	 */
	public Zustand() {
		this.active= true;
		this.email="";
		this.dir="";
	}
	
	public Zustand(String mail) {
		this.email = mail;
	}

	/**
	 * @param email
	 *            eindeutige Identifikation des Nutzers
	 * @param dir
	 *            der Startordner des Nutzers
	 */
	public Zustand(final String email, final String dir) {
		this.active = true;
		this.email = email;
		this.dir = dir;
	}

	/**
	 * Gibt den Aktivitätszustand des Nutzers wieder
	 * 
	 * @return true wenn Nutzer eingeloggt, false wenn nicht
	 */
	public boolean isActive() {
		return this.active;
	}

	/**
	 * Gibt die eindeutige Identifikation des Nutzers
	 * 
	 * @return
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Gibt den aktuellen Ordner des Nutzers
	 * 
	 * @return
	 */
	public String getDir() {
		return this.dir;
	}

	/**
	 * Setzt den Aktivitätszustand des Nutzers
	 * 
	 * @param active
	 */
	public void setActive(final boolean active) {
		this.active = active;
	}

	/**
	 * Setzt die Email
	 * 
	 * @param email
	 */
	public void setEmail(final String email) {
		this.email = email;
	}

	/**
	 * Setzt den derzeitigen Ordner
	 * 
	 * @param dir
	 */
	public void setDir(final String dir) {
		this.dir = dir;
	}

}
