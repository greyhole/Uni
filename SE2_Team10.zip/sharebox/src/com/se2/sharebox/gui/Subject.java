/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.se2.sharebox.gui;

/**
 *
 * @author nvetter
 */
public interface Subject {
    public void registerObserver(TheObserver o);
    public void removeObserver(TheObserver o);
    public void notifyObserver(ObserverEnum ss);
}
