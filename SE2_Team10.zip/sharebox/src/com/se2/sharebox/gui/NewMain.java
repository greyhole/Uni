/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.se2.sharebox.gui;

import java.awt.EventQueue;
import java.lang.reflect.InvocationTargetException;

import com.se2.sharebox.controller.Controller;

/**
 *
 * @author nvetter
 */
public class NewMain {
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, InvocationTargetException {
    	SBMainFrame sb=new SBMainFrame();
    	Controller controle = new Controller(sb);
    	if (!controle.loadConfig()) {
    		System.exit(1);
    	}
        sb.registerObserver(controle);
        EventQueue.invokeLater(sb);
    }

    
}
