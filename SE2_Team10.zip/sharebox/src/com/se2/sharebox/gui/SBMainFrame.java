/*
 * GUI für ShareBox des Teams SE2-Team10
 */
package com.se2.sharebox.gui;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author nvetter
 */
public class SBMainFrame extends javax.swing.JFrame implements Subject,Runnable{
    /**
     * Creates new form SBMainFrame
     *
     */
	
    private HashSet<TheObserver> observers;
    private JPopupMenu popmen;
    private JMenuItem menu;
    private File choosenFile;
    private Object[] choosenDirectory;
    public String tmpString;
    
    /*
     * Konstruktor welcher die GUI aufbaut.
     */
    
    public SBMainFrame() {
        observers =new HashSet<TheObserver>();
        
        buttonGroup1 = new javax.swing.ButtonGroup();
        loginPanel = new javax.swing.JPanel();
        welcomeLabel = new javax.swing.JLabel();
        emailLabel = new javax.swing.JLabel();
        pwLabel = new javax.swing.JLabel();
        loginPwField = new javax.swing.JPasswordField();
        loginEmailField = new javax.swing.JTextField();
        loginBtn = new javax.swing.JButton();
        registerBtn = new javax.swing.JButton();
        spacePanel = new javax.swing.JPanel();
        menuPanel = new javax.swing.JPanel();
        showFilesBtn = new javax.swing.JButton();
        showSettingsBtn = new javax.swing.JButton();
        logoutBtn = new javax.swing.JButton();
        innerSpacePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        filesTree = new javax.swing.JTree();
        settingsPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        settingsEmailLabel = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        usedSpaceLabel = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        avSpaceLabel = new javax.swing.JLabel();
        chPwRadio = new javax.swing.JRadioButton();
        getSpaceRadio = new javax.swing.JRadioButton();
        delAccountRadio = new javax.swing.JRadioButton();
        jLabel14 = new javax.swing.JLabel();
        currentPwField = new javax.swing.JPasswordField();
        settingsAcceptBtn = new javax.swing.JButton();
        moreSpacePanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        blzField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        spaceCombo = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        ktnrField = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        newPwPanel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        newPwField = new javax.swing.JPasswordField();

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());
        this.addWindowListener(new WindowAdapter() {
        	   public void windowClosing(WindowEvent evt) {
        	     closeOperation();
        	   }
        	  });
        
        welcomeLabel.setText("Willkommen bei Sharebox-Ultimate.");

        emailLabel.setText("Email:");

        pwLabel.setText("Password:");

        loginBtn.setText("Login");
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });

        registerBtn.setText("Register");
        registerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loginPanelLayout = new javax.swing.GroupLayout(loginPanel);
        loginPanel.setLayout(loginPanelLayout);
        loginPanelLayout.setHorizontalGroup(
            loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(welcomeLabel)
                    .addGroup(loginPanelLayout.createSequentialGroup()
                        .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pwLabel)
                            .addComponent(emailLabel))
                        .addGap(18, 18, 18)
                        .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(loginPanelLayout.createSequentialGroup()
                                .addComponent(loginBtn)
                                .addGap(18, 18, 18)
                                .addComponent(registerBtn))
                            .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(loginEmailField)
                                .addComponent(loginPwField, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)))))
                .addContainerGap(277, Short.MAX_VALUE))
        );
        loginPanelLayout.setVerticalGroup(
            loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(welcomeLabel)
                .addGap(18, 18, 18)
                .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailLabel)
                    .addComponent(loginEmailField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pwLabel)
                    .addComponent(loginPwField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(loginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginBtn)
                    .addComponent(registerBtn))
                .addContainerGap(306, Short.MAX_VALUE))
        );

        getContentPane().add(loginPanel, "card2");

        menuPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        showFilesBtn.setText("Files");
        showFilesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showFilesBtnActionPerformed(evt);
            }
        });

        showSettingsBtn.setText("Settings");
        showSettingsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showSettingsBtnActionPerformed(evt);
            }
        });

        logoutBtn.setText("Logout");
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(menuPanel);
        menuPanel.setLayout(menuPanelLayout);
        menuPanelLayout.setHorizontalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(showFilesBtn)
                .addGap(18, 18, 18)
                .addComponent(showSettingsBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoutBtn)
                .addContainerGap())
        );
        menuPanelLayout.setVerticalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(showFilesBtn)
                    .addComponent(showSettingsBtn)
                    .addComponent(logoutBtn)))
        );

        innerSpacePanel.setLayout(new java.awt.CardLayout());

        filesTree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filesTreeMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(filesTree);

        innerSpacePanel.add(jScrollPane1, "card3");

        jLabel1.setText("Settings");

        jLabel2.setText("Email:");

        settingsEmailLabel.setText("jLabel3");

        jLabel4.setText("Space (Used):");

        usedSpaceLabel.setText("jLabel5");

        jLabel6.setText("Space (Available):");

        avSpaceLabel.setText("jLabel7");

        buttonGroup1.add(chPwRadio);
        chPwRadio.setText("Change Password");
        chPwRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chPwRadioActionPerformed(evt);
            }
        });

        buttonGroup1.add(getSpaceRadio);
        getSpaceRadio.setText("Get more Space");
        getSpaceRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getSpaceRadioActionPerformed(evt);
            }
        });

        buttonGroup1.add(delAccountRadio);
        delAccountRadio.setText("Delete Accound");
        delAccountRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delAccountRadioActionPerformed(evt);
            }
        });

        jLabel14.setText("Current Password:");

        settingsAcceptBtn.setText("Accept");
        settingsAcceptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                settingsAcceptBtnActionPerformed(evt);
            }
        });

        moreSpacePanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        moreSpacePanel.setVisible(false);

        jLabel8.setText("Get more Space:");

        jLabel9.setText("Value (5€/GB):");

        spaceCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2", "5", "10", "20" }));

        jLabel11.setText("Kt.Nr.:");

        jLabel10.setText("Name:");

        jLabel12.setText("BLZ:");

        javax.swing.GroupLayout moreSpacePanelLayout = new javax.swing.GroupLayout(moreSpacePanel);
        moreSpacePanel.setLayout(moreSpacePanelLayout);
        moreSpacePanelLayout.setHorizontalGroup(
            moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moreSpacePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(moreSpacePanelLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spaceCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(moreSpacePanelLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nameField))
                    .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(moreSpacePanelLayout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(blzField, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(moreSpacePanelLayout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(ktnrField, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        moreSpacePanelLayout.setVerticalGroup(
            moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moreSpacePanelLayout.createSequentialGroup()
                .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(moreSpacePanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(spaceCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(ktnrField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(moreSpacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(blzField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        newPwPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        newPwPanel.setVisible(false);

        jLabel13.setText("New Password:");

        javax.swing.GroupLayout newPwPanelLayout = new javax.swing.GroupLayout(newPwPanel);
        newPwPanel.setLayout(newPwPanelLayout);
        newPwPanelLayout.setHorizontalGroup(
            newPwPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(newPwPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(newPwField, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        newPwPanelLayout.setVerticalGroup(
            newPwPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(newPwPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(newPwPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(newPwField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout settingsPanelLayout = new javax.swing.GroupLayout(settingsPanel);
        settingsPanel.setLayout(settingsPanelLayout);
        settingsPanelLayout.setHorizontalGroup(
            settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(settingsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(settingsPanelLayout.createSequentialGroup()
                        .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addComponent(chPwRadio)
                                .addGap(54, 54, 54)
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(currentPwField, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(settingsPanelLayout.createSequentialGroup()
                                    .addComponent(delAccountRadio)
                                    .addGap(69, 69, 69)
                                    .addComponent(settingsAcceptBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(settingsPanelLayout.createSequentialGroup()
                                    .addComponent(getSpaceRadio)
                                    .addGap(0, 0, Short.MAX_VALUE))))
                        .addContainerGap())
                    .addGroup(settingsPanelLayout.createSequentialGroup()
                        .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(settingsEmailLabel))
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(usedSpaceLabel))
                            .addGroup(settingsPanelLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(avSpaceLabel)))
                        .addGap(398, 398, 398))))
            .addComponent(moreSpacePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(newPwPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        settingsPanelLayout.setVerticalGroup(
            settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settingsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(settingsEmailLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(usedSpaceLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(avSpaceLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(moreSpacePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(newPwPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chPwRadio)
                    .addComponent(jLabel14)
                    .addComponent(currentPwField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(getSpaceRadio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(settingsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(delAccountRadio)
                    .addComponent(settingsAcceptBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        innerSpacePanel.add(settingsPanel, "card2");

        javax.swing.GroupLayout spacePanelLayout = new javax.swing.GroupLayout(spacePanel);
        spacePanel.setLayout(spacePanelLayout);
        spacePanelLayout.setHorizontalGroup(
            spacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menuPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(innerSpacePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        spacePanelLayout.setVerticalGroup(
            spacePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(spacePanelLayout.createSequentialGroup()
                .addComponent(menuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(innerSpacePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(spacePanel, "card3");
        
        popmen= new JPopupMenu();
        menu= new JMenuItem( "Create Folder");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                createFolderActionPerformed(evt);
            }
                });
        popmen.add( menu );
        
        menu= new JMenuItem( "Upload");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                uploadActionPerformed(evt);
            }
                });
        popmen.add( menu );
        menu= new JMenuItem( "Download");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                downloadActionPerformed(evt);
            }
                });
        popmen.add( menu );
        menu= new JMenuItem( "Invite User");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                inviteActionPerformed(evt);
            }
                });
        popmen.add( menu );
        menu= new JMenuItem( "Uninvite");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                uninviteActionPerformed(evt);
            }
                });
        popmen.add( menu );
        menu= new JMenuItem( "Delete");
        menu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                deleteActionPerformed(evt);
            }
                });
        popmen.add( menu );
        
        pack();
    }
    /**
     * Informieren der Observer das Programm beendet werden soll.
     */
    private boolean closeOperation(){
    	this.notifyObserver(ObserverEnum.exit);
    	return true;
    }
    /**
     * Beende GUI.
     */
    public void exitGUI(){
    	System.exit(0);
    }
    /**
     * Hole Email aus GUI zum Login oder zum Registrieren. 
     * @return String Email des Nutzers.
     */
    public String getLoginEmail(){
        return this.loginEmailField.getText();
    }
    /**
     * Hole Passwort aus GUI zum Login oder zum Registrieren.
     * @return char[] Passwort des Nutzers.
     */
    public char[] getLoginPw(){
        return this.loginPwField.getPassword();
    }
    /**
     * Hole File welche vom Nutzer zum Upload oder Download gewählt wurde.
     * @return File 
     */
    public File getFile(){
        return this.choosenFile;
    }
    /**
     * Übergebe vom Nutzer gewählte Datei/Ordner mit Pfad.
     * @return Object[]
     */
    public Object[] getTreePath(){
        return this.choosenDirectory;
    }
    /**
     * Übergebe vom Nutzer in Dialog eingegebene Daten (Nutzer zum Invite,Nutzer zum Deinvite,Ordnername
     *  zum Neuerstellen).
     *  @return String 
     */
    public String getDialogInput(){
        return this.tmpString;
    }
    /**
     * Hole BLZ zur erweiterung des Space.
     * @return String
     */
    public String getBlz(){
        return this.blzField.getText();
    }
    /**
     * Hole KtNr zur erweiterung des Space.
     * @return String
     */
    public String getKtnr(){
        return this.ktnrField.getText();
    }
    /**
     * Hole Name des Kontoinhabers zur erweiterung des Space.
     * @return String
     */
    public String getPayName(){ 
    	return this.nameField.getText();
    }
    /**
     * Hole Neues PW zum ändern.
     *
     * @return char[]
     */
    public char[] getNewPw(){
        return this.newPwField.getPassword();
    } 
    /**
     * Hole Passwort zur Sicherheitsabfrage.
     * @return char[]
     */
    public char[] getCheckPw(){
        return this.currentPwField.getPassword();
    } 
    
    /**
     * Setze Liste der Freigegebenen Nutzer zur auswahl welcher Deinvited werden soll.
     * Und informiere Observer über Auswahl.
     * @param list
     */
    public void setInvitedList(Object[] list){
        this.tmpString = (String)JOptionPane.showInputDialog(
                    this,
                    "Choose Person:","Uninvite",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    list,
                    "");
        this.notifyObserver(ObserverEnum.kill);
    }
    
    /**
     * Zeige dem Nutzer vom Observer gewählten Dialog.
     * succes = Es hat Funktioniert.
     * error = Du darfst das nicht.
     * wrong = Login oder Registrierung hat nicht geklappt.
     * exists = Nutzer kann nicht registriert werden. 
     * @param ss
     */
    public void displayDialog(DialogEnum ss){
        switch(ss){
            case success:
                JOptionPane.showMessageDialog(this,"Operation succesfull.");
                break;
            case error:
                JOptionPane.showMessageDialog(this,"Operation not allowed.","Error",JOptionPane.ERROR_MESSAGE);
                break;
            case wrong:
                JOptionPane.showMessageDialog(this,"Wrong Logindata or User not registered.");   
                break;
            case exists:
                JOptionPane.showMessageDialog(this,"Email exists.","Error",JOptionPane.ERROR_MESSAGE);
                this.loginEmailField.setText("");
                this.loginPwField.setText("");
                break;
        }
    }
    /**
     * Hole zusätzlich Wert für Speicher.
     * @return Zahl als String 
     */
    public String getSpace(){
        return this.spaceCombo.getSelectedItem().toString();
    }
    
    private void uninviteActionPerformed(ActionEvent evt){
        this.choosenDirectory = this.filesTree.getSelectionPath().getPath();
        this.notifyObserver(ObserverEnum.listtokill);
    }
    
    private void inviteActionPerformed(ActionEvent evt){
      this.tmpString = (String)JOptionPane.showInputDialog(this,"Enter User Email-Adress:","Invite User",
                JOptionPane.PLAIN_MESSAGE,null,null,"");
      this.choosenDirectory = this.filesTree.getSelectionPath().getPath();
      this.notifyObserver(ObserverEnum.invite);
    }
    
    private int createFolderActionPerformed(ActionEvent evt){
        this.tmpString = (String)JOptionPane.showInputDialog(this,"Enter Directoryname","Create Directory",
                JOptionPane.PLAIN_MESSAGE,null,null,"");
        TreePath path=this.filesTree.getSelectionPath();
        if (this.filesTree.getModel().isLeaf(path.getLastPathComponent()))
            this.choosenDirectory = path.getParentPath().getPath();
        else
            this.choosenDirectory = path.getPath();
        this.notifyObserver(ObserverEnum.create);
        return 1;
    }
    
    private int uploadActionPerformed(ActionEvent evt){
        TreePath path=this.filesTree.getSelectionPath();
        if (this.filesTree.getModel().isLeaf(path.getLastPathComponent()))
            this.choosenDirectory = path.getParentPath().getPath();
        else
            this.choosenDirectory = path.getPath();
        final JFileChooser fc = new JFileChooser();
        int returnval = fc.showOpenDialog(this.filesTree);
        if (returnval == JFileChooser.APPROVE_OPTION){
            this.choosenFile= fc.getSelectedFile();
        }
        this.notifyObserver(ObserverEnum.upload);
        return 1;
    }
    
    private int downloadActionPerformed(ActionEvent evt){
        TreePath path=this.filesTree.getSelectionPath();
        if (this.filesTree.getModel().isLeaf(path.getLastPathComponent()))
            this.choosenDirectory = path.getPath();
        else {this.displayDialog(DialogEnum.error);
        return 0;
        }
        final JFileChooser fc = new JFileChooser();
        int returnval = fc.showOpenDialog(this.filesTree);
        if (returnval == JFileChooser.APPROVE_OPTION){
            this.choosenFile= fc.getSelectedFile();
        }
        return 1;
    }
    
    private int deleteActionPerformed(ActionEvent evt){
        this.choosenDirectory = this.filesTree.getSelectionPath().getPath();
        this.notifyObserver(ObserverEnum.delete);
        return 1;
    }
    
    /**
     * Setze den Nutzer als Eingeloggt...also fülle und zeige den Datenbaum.
     * @param top
     * @return boolean
     */
    public boolean setLogedIn(DefaultMutableTreeNode top){
        this.filesTree.setModel(new DefaultTreeModel(top));
        ((CardLayout) this.getContentPane().getLayout()).show(this.getContentPane(), "card3");
        ((CardLayout)innerSpacePanel.getLayout()).show(innerSpacePanel, "card3");
        this.loginEmailField.setText("");
        this.loginPwField.setText("");
        return true;
    }
    
    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {
        this.notifyObserver(ObserverEnum.login);       
    }
    
    private void registerBtnActionPerformed(java.awt.event.ActionEvent evt) {
        this.notifyObserver(ObserverEnum.register);
    }
    
    private void showFilesBtnActionPerformed(java.awt.event.ActionEvent evt) {
        this.notifyObserver(ObserverEnum.showFiles);
    }
    
    private void showSettingsBtnActionPerformed(java.awt.event.ActionEvent evt) {
        this.notifyObserver(ObserverEnum.showSettings);
        
    }
    
    /**
     * Setze die Settings des Nutzers und zeige ihm die Ansicht.
     * @param stats
     * @return boolean
     */
    public boolean setSettings(Object[] stats){
        this.settingsEmailLabel.setText((String) stats[0]);
        this.usedSpaceLabel.setText((String)stats[1] + " GB");
        this.avSpaceLabel.setText((String)stats[2]+" GB");
        this.nameField.setText("");
       this.blzField.setText("");
       this.ktnrField.setText("");
       this.newPwField.setText("");
       this.currentPwField.setText("");
       this.newPwPanel.setVisible(false);
       this.moreSpacePanel.setVisible(false);
       ((CardLayout)innerSpacePanel.getLayout()).show(innerSpacePanel, "card2");
        return true;
    }
    
    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {
        this.notifyObserver(ObserverEnum.logout);
    }

    private void filesTreeMousePressed(java.awt.event.MouseEvent evt) {
        if (evt.isPopupTrigger()){
            filesTree.setSelectionRow(filesTree.getClosestRowForLocation(evt.getX(), evt.getY()));
            popmen.show(evt.getComponent(), evt.getX(), evt.getY());}
    }

    private void chPwRadioActionPerformed(java.awt.event.ActionEvent evt) {
       this.nameField.setText("");
       this.blzField.setText("");
       this.ktnrField.setText("");
       this.newPwField.setText("");
       this.currentPwField.setText("");
       this.newPwPanel.setVisible(true);
       this.moreSpacePanel.setVisible(false);
    }

    private void getSpaceRadioActionPerformed(java.awt.event.ActionEvent evt) {
       this.nameField.setText("");
       this.blzField.setText("");
       this.ktnrField.setText("");
       this.newPwField.setText("");
       this.currentPwField.setText("");
       this.newPwPanel.setVisible(false);
       this.moreSpacePanel.setVisible(true);
    }

    private void delAccountRadioActionPerformed(java.awt.event.ActionEvent evt) {
               this.nameField.setText("");
       this.blzField.setText("");
       this.ktnrField.setText("");
       this.newPwField.setText("");
       this.currentPwField.setText("");
       this.newPwPanel.setVisible(false);
       this.moreSpacePanel.setVisible(false);
    }

    private void settingsAcceptBtnActionPerformed(java.awt.event.ActionEvent evt) {
        if (this.chPwRadio.isSelected())
            this.notifyObserver(ObserverEnum.changePw);
        else if (this.getSpaceRadio.isSelected())
            this.notifyObserver(ObserverEnum.getSpace);
        else this.notifyObserver(ObserverEnum.delAcc);
    }

    /**
     * logge Nutzer aus.
     * @return boolean
     */
    public boolean setLoggedOut(){
    	((CardLayout) this.getContentPane().getLayout()).show(this.getContentPane(), "card2");
    	return true;
    }
    @Override
    public void registerObserver(TheObserver o) {
        this.observers.add(o);
    }

    @Override
    public void removeObserver(TheObserver o) {
        this.observers.remove(o);
    }
    
    @Override
    public void run() {
          this.setVisible(true);
            }
    
    @Override
    public void notifyObserver(ObserverEnum ss) {
        Iterator<TheObserver> i = observers.iterator();
        while (i.hasNext())
                i.next().update(ss);
                
    }
    
    
    private javax.swing.JLabel avSpaceLabel;
    public javax.swing.JTextField blzField;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton chPwRadio;
    public javax.swing.JPasswordField currentPwField;
    private javax.swing.JRadioButton delAccountRadio;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JTree filesTree;
    private javax.swing.JRadioButton getSpaceRadio;
    private javax.swing.JPanel innerSpacePanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    public javax.swing.JTextField ktnrField;
    private javax.swing.JButton loginBtn;
    public javax.swing.JTextField loginEmailField;
    private javax.swing.JPanel loginPanel;
    public javax.swing.JPasswordField loginPwField;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JPanel moreSpacePanel;
    public javax.swing.JTextField nameField;
    public javax.swing.JPasswordField newPwField;
    private javax.swing.JPanel newPwPanel;
    private javax.swing.JLabel pwLabel;
    private javax.swing.JButton registerBtn;
    private javax.swing.JButton settingsAcceptBtn;
    private javax.swing.JLabel settingsEmailLabel;
    private javax.swing.JPanel settingsPanel;
    private javax.swing.JButton showFilesBtn;
    private javax.swing.JButton showSettingsBtn;
    public javax.swing.JComboBox spaceCombo;
    private javax.swing.JPanel spacePanel;
    private javax.swing.JLabel usedSpaceLabel;
    private javax.swing.JLabel welcomeLabel;
        
}
