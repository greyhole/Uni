/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.se2.sharebox.gui;

/**
 *
 * @author nvetter
 */
public enum ObserverEnum {
    download,exit,listtokill,kill,invite,create,upload,delete,login,register,showFiles,showSettings,logout,changePw,getSpace,delAcc
}
