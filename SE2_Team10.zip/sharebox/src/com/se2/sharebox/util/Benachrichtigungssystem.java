package com.se2.sharebox.util;

import java.util.Properties;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
/**
 * Benachrichtigungssystem
 * sendet Emails zur Benachrichtigung der Benutzer
 * 
 * @author SE_Team10
 * @version 1.0
 */
public class Benachrichtigungssystem {
	private static final String HOST="mail.gmx.net";
	private static final int PORT=587;
	private static final String USER="ShareBoxUltimate@gmx.net";
	private static final String PASS="SE_Team10";
	private static Properties props;
	/**
	 * Sendet eine Anmeldebest�tigung
	 * @param mail Die Emailadresse, an die gesendet wird
	 * @return true wenn erfolgreich, false sonst
	 */
	public static boolean anmelden(final String mail){
		final String message ="Hallo "+mail+"!\n" +
				"\n" +
				"Sie haben sich bei ShareBoxUltimate\n" +
				"registriert.\n" +
				"\n" +
				"Melden Sie sich bei ShareBoxUltimate an\n" +
				"um mit der Arbeit zu beginnen.\n" +
				"\n" +
				"Viel Spa� bei der Nutzung von ShareBoxUltimate!\n" +
				"\n" +
				"Ihr ShareBoxUltimate-Team\n";
		
		return sendEmail(mail,message);
	}
	
	/**
	 * Sendet eine Benachrichtung �ber eine Einladung
	 * @param mail Die Emailadresse, an die gesendet wird
	 * @param link Angabe der Freigabe, zu der eingeladen wurde
	 * @return true wenn erfolgreich, false sonst
	 */
	public static boolean einladen(final String mail, final String link){
		final String message ="Hallo "+mail+"!\n" +
				"\n" +
				"Sie wurden eingeladen zum Verzeichnis:\n" +
				link+"\n" +
				"\n" +
				"Melden Sie sich bei ShareBoxUltimate an\n" +
				"um den Inhalt zu sehen und zu bearbeiten.\n" +
				"\n" +
				"Viel Spa� bei der Nutzung von ShareBoxUltimate!\n" +
				"\n" +
				"Ihr ShareBoxUltimate-Team\n";
		
		return sendEmail(mail,message);
	}
	
	/**
	 * sendet eine Email mit definierbarem Text
	 * @param mail Die Emailadresse, an die gesendet wird
	 * @param message Der Text, der in der Email enthalten sein soll
	 * @return true wenn erfolgreich, false sonst
	 */
	public static boolean sendEmail(final String mail, final String message){
		try{
			props=new Properties();
	    	props.put("mail.smtp.auth", "true");
	    	props.put("mail.smtp.starttls.enable", "true");
        	final Session session=Session.getInstance(props);
        	final Transport transport=session.getTransport("smtp");
        	transport.connect(HOST, PORT, USER, PASS);
        	
        	if(!mail.matches("[a-zA-Z0-9\\._\\-]{3,}\\@[a-zA-Z0-9\\._\\-]{3,}\\.[a-zA-Z]{2,6}"))
    			return false;
        	final Address[] addresses=InternetAddress.parse(mail);
        	
        	final Message message1=new MimeMessage(session);
        	message1.setFrom(new InternetAddress(USER));
        	message1.setRecipients(Message.RecipientType.TO, addresses);
        	message1.setSubject("Information von ShareBoxUltimate");
        	
        	message1.setText(message);
        	
        	transport.sendMessage(message1, addresses);
        	
        	transport.close();
			return true;
		}catch(Exception e){
			return false;
		}
	}
}