package com.se2.sharebox.logging;

import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.Calendar;

/**
 * Zum loggen saemtlicher ereignisse in einem Ordner
 * @author wiesel
 * @version 1.0
 */

public class Logging {
	public static final String LOGFILE 	= "log";
	public static final String LOGDIR	= "./";
	
	private File file;
	private FileWriter writer;
	
	private Calendar calendar = Calendar.getInstance();
	
	private String filename;
	private String dir;
	
	/**	
	 * 
	 * @param dir gibt den Ordner an in dem die Logdatei angelegt werden soll
	 * @param filename gibt den Namen der Logdatei an
	 */
	public Logging(final String dir, final String filename){
		this.dir 		= dir;
		this.filename 	= filename;
	}
	
	/**
	 * 
	 * @param dir gibt den Ordner an in dem die Logdatei angelegt werden soll
	 */
	public Logging(final String dir){
		this(dir, LOGFILE);
	}
	
	public Logging(){
		this(LOGDIR, LOGFILE);
	}
	
	/**
	 * Zum Loggen in eine Datei und auf die Konsole
	 * @param logmessage Nachricht die geloggt werden soll
	 */
	public void log(final String logmessage){
		file = new File( this.dir + this.filename );
		
		try{
			writer = new FileWriter ( file, true );
			calendar.setTime(new java.util.Date());

			writer.write( 	String.valueOf( calendar.get(Calendar.DAY_OF_MONTH ) ) + "." +
							String.valueOf( calendar.get(Calendar.MONTH ) ) + "." +
							String.valueOf( calendar.get(Calendar.YEAR ) ) + " " + 
							String.valueOf( calendar.get(Calendar.HOUR ) ) + ":" +
							String.valueOf( calendar.get(Calendar.MINUTE ) ) + ":" +
							String.valueOf( calendar.get(Calendar.SECOND ) ) 
			);
			
			writer.write(" : ");
			writer.write ( logmessage );
			writer.write ( System.getProperty("line.separator") );
			writer.flush ();
			writer.close ();
			
		} catch (IOException e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Gibt den Logdatei-Namen
	 * @return String
	 */
	public String getFilename(){
		return this.filename;
	}
	
	/**
	 * Gibt den Ordner in dem geloggt werden soll
	 * @return String
	 */
	public String getDir(){
		return this.dir;
	}
	
	/**
	 * Setzt den Dateinamen der LogDatei
	 * @param filename Nameder LogDatei
	 */
	public void setFilename(final String filename){
		this.filename = filename;
	}
	
	/**
	 * Setzt den Ordner in dem geloggt werden soll
	 * @param dir OrdnerName bzw. OrdnerPfad
	 */
	public void setDir(final String dir){
		this.dir = dir;
	}
}
