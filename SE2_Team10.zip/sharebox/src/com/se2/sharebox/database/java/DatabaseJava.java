package com.se2.sharebox.database.java;

import java.io.File;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.naming.NoPermissionException;

import com.se2.sharebox.database.IDatabase;
import com.se2.sharebox.logging.Logging;

/**
 * Simple database. Stores files within the filesystem.
 * 
 * @author Henrik Jürges
 * 
 */
public class DatabaseJava implements IDatabase {

	private File dbPath = null;

	private Logging logger = null;

	private HashMap<String, Userprofile> profiles = new HashMap<String, Userprofile>();

	/**
	 * @param dbPath
	 *            - Path to the database root file. Log file will be the dbPath.
	 */
	public DatabaseJava(String dbPath) {
		this.dbPath = new File(dbPath);
		this.logger = new Logging(dbPath, "dblog");
	}

	/**
	 * @param dbPath
	 *            - Path to the database root file.
	 * @param logger
	 *            - Logger for status.
	 */
	public DatabaseJava(String dbPath, Logging logger) {
		this.dbPath = new File(dbPath);
		this.logger = logger;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#createUser(java.lang.String,
	 * java.lang.String)
	 */
	public boolean createUser(String mail, String pass) {
		boolean ret = true;
		try {
			profiles.put(mail,
					new Userprofile(mail, DatabaseFunctions.sha256(pass)));
			addFolder("");
		} catch (NoSuchAlgorithmException e) {
			logger.log("[DB]: SHA-256 Algorithm not found.");
			ret = false;
		}
		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#removeUser(java.lang.String)
	 */
	public boolean removeUser(String mail) {
		removeFolder(mail, "");
		profiles.remove(mail);
		return true;
	}

	public boolean userExists(String mail) {
		return profiles.containsKey(mail);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#equalsPass(java.lang.String,
	 * java.lang.String)
	 */
	public boolean equalsPass(String pass, String mail) {
		boolean ret = false;
		try {
			byte[] hashPass = DatabaseFunctions.sha256(pass);
			Userprofile usr = profiles.get(mail);
			ret = Arrays.equals(hashPass, usr.getPass());
		} catch (NoSuchAlgorithmException e) {
			logger.log("[DB]: SHA-256 Algorithm not found.");
		}
		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#addFile(java.lang.String,
	 * java.io.File, java.lang.String)
	 */
	public boolean addFile(String mail, File input, String subpath) {
		boolean ret = false;
		File destFolder = new File(dbPath, subpath);
		File destFile = new File(destFolder, input.getName());
		try {
			destFolder.mkdirs();
			isNewFileAllowed(mail, input.length());
			DatabaseFunctions.copy(input, destFile, logger);
		} catch (NoPermissionException e) {
			logger.log("[DB]: Adding file aborted. " + e.getMessage());
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see com.se2.sharebox.database.IDatabase#downloadFile(java.lang.String, java.io.File, java.lang.String)
	 */
	public boolean downloadFile(String mail, File dest, String subpath) {
		boolean ret = false;
		File input = new File(dbPath, subpath);
		DatabaseFunctions.copy(input, dest, logger);
		return ret;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#addFolder(java.lang.String,
	 * java.lang.String)
	 */
	public boolean addFolder(String subpath) {
		boolean ret = false;
		File file = new File(dbPath, subpath);
		ret = file.mkdirs();
		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#removeFile(java.lang.String,
	 * java.lang.String)
	 */
	public boolean remove(String mail, String subpath) {
		File remove = new File(dbPath, subpath);
		boolean ret;
		if (remove.exists()) {
			ret = remove.delete();
			setUsedSpaceToActualUsedSpace(mail);
			logger.log("[DB]: Removing " + remove.getName());
		} else {
			ret = false;
			// TODO linked ressources
		}

		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#removeFolder(java.lang.String,
	 * java.lang.String)
	 */
	public boolean removeFolder(String mail, String subpath) {
		File remove = new File(dbPath, subpath);
		remove(remove);
		setUsedSpaceToActualUsedSpace(mail);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#getRootView(java.lang.String)
	 */
	public File getRootView(String mail) {
		File root = new File(dbPath, convertAtSymbol(mail));
		return root;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#getLinkedFiles(java.lang.String)
	 */
	public HashMap<String, ArrayList<File>> getNiceFiles(String mail) {
		HashMap<String, ArrayList<File>> ret = new HashMap<String, ArrayList<File>>();
		ret = profiles.get(mail).getNiceFiles();
		return ret;
	}

	public boolean addNiceFiles(File linkedFile, String otherUserMail,
			String currentUserMail) {
		HashMap<String, ArrayList<File>> niceFiles = this
				.getNiceFiles(currentUserMail);

		if (niceFiles.containsKey(otherUserMail)) {
			// file exestiert noch nicht
			if (!niceFiles.get(otherUserMail).contains(linkedFile)) {
			niceFiles.get(otherUserMail).add(linkedFile);
			}
		} else {
			niceFiles.put(otherUserMail, new ArrayList<File>());
			niceFiles.get(otherUserMail).add(linkedFile);
		}
		return true;
	}

	public boolean addBadFiles(File linkedFile, String otherUserMail,
			String currentUserMail) {
		HashMap<File, ArrayList<String>> badFiles = getBadFiles(currentUserMail);
		
		if (badFiles.containsKey(linkedFile)) {
			// user existiert noch nicht
			if (!badFiles.get(linkedFile).contains(otherUserMail)) {
				badFiles.get(linkedFile).add(otherUserMail);
			}
		} else {
			badFiles.put(linkedFile, new ArrayList<String>());
			badFiles.get(linkedFile).add(otherUserMail);
		}
		return true;
	}

	public HashMap<File, ArrayList<String>> getBadFiles(String mail) {
		return profiles.get(mail).getBadFiles();
	}

	/**
	 * Checks if storing a file is allowed.
	 * 
	 * @param mail
	 *            - The user mail
	 * @param size
	 *            - Inputfile size
	 * @throws NoPermissionException
	 *             - If the user has no more free space
	 */
	public void isNewFileAllowed(String mail, long size)
			throws NoPermissionException {
		Userprofile usr = profiles.get(mail);
		long actualSpace = usr.getActualSpace();
		long maxSpace = usr.getMaxSpace();
		actualSpace = +size;
		// with this input file
		if (actualSpace >= maxSpace) {
			throw new NoPermissionException("No more space, to add File");
		} else {
			usr.setActualSpace(actualSpace);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.se2.sharebox.database.IDatabase#increaseMaxSpace(java.lang.String,
	 * long)
	 */
	public void increaseMaxSpace(String mail, long space) {
		profiles.get(mail).setMaxSpace(space);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.se2.sharebox.database.IDatabase#setUsedSpaceToActualUsedSpace(java
	 * .lang.String)
	 */
	public void setUsedSpaceToActualUsedSpace(String mail) {
		long actualSize = DatabaseFunctions.getFolderSize(new File(
				convertAtSymbol(mail)));
		profiles.get(mail).setActualSpace(actualSize);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#getUsedSpace(java.lang.String)
	 */
	public long getUsedSpace(String mail) {
		return profiles.get(mail).getActualSpace();
	}

	public boolean setPass(String mail, String pass) {
		boolean retVal;
		try {
			byte[] newPass = DatabaseFunctions.sha256(pass);
			profiles.get(mail).setPass(newPass);
			retVal = true;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			retVal = false;
		}
		return retVal;
	}

	public long getMaxSpace(String mail) {
		return profiles.get(mail).getMaxSpace();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#saveDatabase()
	 */
	public void saveDatabase() {
		DatabaseFunctions.serializeDatabase(this.profiles, new File(dbPath,
				"db.ser"), logger);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.se2.sharebox.database.IDatabase#loadDatabase()
	 */
	public void loadDatabase() {
		this.profiles.putAll(DatabaseFunctions.loadDatabase(new File(dbPath,
				"db.ser"), logger));
	}

	/**
	 * @param s
	 *            - String to convert
	 * @return - the input String with <tt>"@" -> "_"</tt>
	 */
	private String convertAtSymbol(String s) {
		return s.replace("@", "_");
	}

	/**
	 * removes folder and files recursivly
	 * 
	 * @param root
	 *            - root folder
	 */
	private void remove(File root) {
		if (root.isDirectory()) {
			File[] children = root.listFiles();
			for (File child : children) {
				remove(child);
			}
			root.delete();
			logger.log("[DB]: Removing " + root.getName());
		} else {
			root.delete();
			logger.log("[DB]: Removing " + root.getName());
		}
	}

	/**
	 * stores all files under root in a set
	 * 
	 * @param root
	 *            - first search folder
	 * @param files
	 *            - where all files are stored
	 */
	private void listFiles(File root, Collection<File> files) {
		files.add(root);
		if (root.isDirectory()) {
			File[] children = root.listFiles();
			for (File child : children) {
				listFiles(child, files);
			}
		}
	}
}
