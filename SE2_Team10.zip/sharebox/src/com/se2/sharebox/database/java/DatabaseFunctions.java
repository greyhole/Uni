package com.se2.sharebox.database.java;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.se2.sharebox.logging.Logging;

public class DatabaseFunctions {

	public static boolean copy(File src, File dest, Logging logger) {
		InputStream is = null;
		OutputStream os = null;
		ReadableByteChannel inputChannel = null;
		WritableByteChannel outputChannel = null;
		boolean ret = true;

		try {
			is = new FileInputStream(src);
			os = new FileOutputStream(dest);
			inputChannel = Channels.newChannel(is);
			outputChannel = Channels.newChannel(os);
			copy(inputChannel, outputChannel);

		} catch (FileNotFoundException e) {
			ret = false;
			logger.log("[DB]: Source file not found.");
		} catch (IOException e) {
			ret = false;
			logger.log("[DB]: IO Error ocurred.");
		} finally {
			close(inputChannel, logger);
			close(outputChannel, logger);
			close(is, logger);
			close(os, logger);
		}
		return ret;
	}

	private static void copy(ReadableByteChannel src, WritableByteChannel dest)
			throws IOException {
		ByteBuffer buffer = ByteBuffer.allocateDirect(16 * 1024);
		// prepare buffer for copy
		buffer.clear();
		while (src.read(buffer) != -1) {
			// prepare buffer to be drained
			buffer.flip();
			// write to the channel, maybe blocking
			dest.write(buffer);
			// if partial transfer, shift remainder down
			buffer.compact();
		}
		// eof will leave buffer filled
		buffer.flip();
		// drain buffer
		while (buffer.hasRemaining()) {
			dest.write(buffer);
		}
	}

	public static void close(Closeable c, Logging logger) {
		if (c != null) {
			try {
				c.close();
			} catch (IOException e) {
				logger.log("[DB]: Failed to close I/O stream.");
			}
		}
	}

	public static byte[] sha256(String pass) throws NoSuchAlgorithmException {
		MessageDigest md;
		md = MessageDigest.getInstance("SHA-256");
		md.update(pass.getBytes());
		return md.digest();
	}

	public static boolean serializeDatabase(HashMap<String, Userprofile> users, File savePath, Logging logger) {
		ObjectOutputStream oos = null;
		FileOutputStream fos = null;
		boolean ret = true;
		try {
			fos = new FileOutputStream(savePath);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(users);
		} catch (IOException io) {
			logger.log("[DB]: Failed to save database.");
			ret = false;
		} finally {
			close(oos, logger);
			close(fos, logger);
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	public static HashMap<String, Userprofile> loadDatabase(File loadPath, Logging logger) {
		ObjectInputStream ois = null;
		FileInputStream fis = null;
		HashMap<String, Userprofile> users = null;
		try {
			fis = new FileInputStream(loadPath);
			ois = new ObjectInputStream(fis);
			Object obj = ois.readObject();
			if (obj instanceof HashMap<?, ?>) {
				users = (HashMap<String, Userprofile>)obj;
			}

		} catch (IOException io) {
			logger.log("[DB]: Failed to load database.");
			users = new HashMap<>();
		} catch (ClassNotFoundException e) {
			logger.log("[DB]: Failed to load class.");
			users = new HashMap<>();
		} finally {
			close(ois, logger);
			close(fis, logger);
		}

		return users;
	}
	
	public static long getFolderSize(File root) {
		long size = 0;
		if (root.isDirectory()) {
			File[] children = root.listFiles();
			for (File child: children) {
				if (child.isDirectory()) {
					size =+ getFolderSize(child);
				} else {
					size =+ child.length();
				}
			}
		} else {
			size =+ root.length();
		}
		return size;
	}
}
