package com.se2.sharebox.database.java;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Userprofile implements Serializable {

	private static final long serialVersionUID = 43L;

	private String mail;

	private byte[] hashPass;

	private HashMap<String, ArrayList<File>> niceFiles = null;
	private HashMap<File, ArrayList<String>> badFiles = null;

	private long actualSpace;

	private long maxSpace;

	public Userprofile(String mail, byte[] hashPass) {
		this.hashPass = hashPass;
		this.mail = mail;
		this.niceFiles = new HashMap<String, ArrayList<File>>();
		this.badFiles = new HashMap<File, ArrayList<String>>();
		// 1GB = 1073741824 Byte
		this.maxSpace = 1073741824;
		this.actualSpace = 0;
	}

	public void setPass(byte[] hashPass) {
		this.hashPass = hashPass;
	}

	public byte[] getPass() {
		return hashPass;
	}

	public String getMail() {
		return this.mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setNiceFiles(HashMap<String, ArrayList<File>> nice) {
		this.niceFiles = nice;
	}

	public HashMap<String, ArrayList<File>> getNiceFiles() {
		return this.niceFiles;
	}

	public void setBadFiles(HashMap<File, ArrayList<String>> bad) {
		this.badFiles = bad;

	}

	public HashMap<File, ArrayList<String>> getBadFiles() {
		return this.badFiles;
	}

	public void setActualSpace(long space) {
		this.actualSpace = space;
	}

	public long getActualSpace() {
		return this.actualSpace;
	}

	public long getMaxSpace() {
		return this.maxSpace;
	}

	public void setMaxSpace(long space) {
		this.maxSpace = space;
	}
}
