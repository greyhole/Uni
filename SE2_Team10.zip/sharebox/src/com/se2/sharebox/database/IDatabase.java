package com.se2.sharebox.database;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public interface IDatabase {

	/**
	 * @param mail - User mail
	 * @param pass - User password
	 * @return true, if user and user root folder created
	 */
	boolean createUser(String mail, String pass);

	/**
	 * @param mail - User mail
	 * @return true, if user and files are removed
	 */
	boolean removeUser(String mail);
	
	/**
	 * @param mail - User mail
	 * @param pass - User password
	 * @return true, if the hashes are equal
	 */
	boolean equalsPass(String mail, String pass);
	
	/**
	 * @param mail - User mail
	 * @param subpath - Where we create the folder, includes foldername
	 * @return - true, if folder and parentfolders created successfully
	 */
	boolean addFolder(String subpath);
	
	/**
	 * The subpath doesn't include the filename. 
	 * 
	 * @param mail - User mail
	 * @param input - File you want to store
	 * @param subpath - Where the file will be stored
	 * @return - true, if the file was successfully copied
	 */
	boolean addFile(String mail, File input, String subpath);
	
	/**
	 * @param mail - User mail
	 * @param subpath - Path to the folder, including foldername
	 * @return true, if the folder and all subfolder and files are removed
	 */
	boolean removeFolder(String mail, String subpath);
	
	/**
	 * @param mail - User mail
	 * @param subpath - Path to the file, including the filename
	 * @return - true, if the file is removed
	 */
	boolean remove(String mail, String subpath);
	
	/**
	 * Returns the root file of a user.
	 * @param mail - User mail
	 * @return - A file pointing to the users root folder.
	 */
	File  getRootView(String mail);
		
	/**
	 * @param mail
	 * @return
	 */
	public HashMap<String, ArrayList<File>> getNiceFiles(String mail);
	/**
	 * @param linkedFile
	 * @param currentMail
	 * @param invitedMail
	 * @return
	 */
	public boolean addNiceFiles(File linkedFile, String currentMail,
			String invitedMail);
	
	/**
	 * @param linkedFile
	 * @param currentMail
	 * @param invitedMail
	 * @return
	 */
	public boolean addBadFiles(File linkedFile, String currentMail,
			String invitedMail);
	
	/**
	 * @param mail
	 * @return
	 */
	public HashMap<File, ArrayList<String>> getBadFiles(String mail);
	
	
	/**
	 * @param mail
	 * @param dest
	 * @param subpath
	 * @return
	 */
	public boolean downloadFile(String mail, File dest, String subpath);
	
	/**
	 * @param mail
	 * @param pass
	 * @return
	 */
	public boolean setPass(String mail, String pass);
	/**
	 * Increases the user space.
	 * 
	 * @param mail
	 *            - The users mail
	 * @param space
	 *            - How much he buyed in bytes.
	 */
	void increaseMaxSpace(String mail, long space);
	/**
	 * @param mail
	 * @return
	 */
	public boolean userExists(String mail);
	/**
	 * Cycles through the user directory and sets the actual user space to his
	 * size. Folder have no size.
	 * 
	 * @param mail
	 *            - The user mail
	 */
	void setUsedSpaceToActualUsedSpace(String mail);

	/**
	 * Get actual space used by this user.
	 * @param mail - The user mail
	 * @return - The used space in bytes
	 */
	public long getUsedSpace(String mail);
	
	/**
	 * Get maximal space for this user.
	 * @param mail - The user mail
	 * @return - The max amount space in bytes
	 */
	public long getMaxSpace(String mail);
	
	/**
	 * Serialize this Database to dbPath/"db.ser" 
	 */
	public void saveDatabase();
	
	/**
	 * Loads the Database from dbPath/"db.ser"
	 */
	public void loadDatabase();
}
