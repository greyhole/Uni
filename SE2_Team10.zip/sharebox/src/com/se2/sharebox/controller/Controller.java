package com.se2.sharebox.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.tree.DefaultMutableTreeNode;

import com.se2.sharebox.database.IDatabase;
import com.se2.sharebox.database.java.DatabaseJava;
import com.se2.sharebox.gui.DialogEnum;
import com.se2.sharebox.gui.ObserverEnum;
import com.se2.sharebox.gui.SBMainFrame;
import com.se2.sharebox.gui.TheObserver;
import com.se2.sharebox.logging.Logging;
import com.se2.sharebox.util.Zahlungssystem;
import com.se2.sharebox.zustand.Zustand;

public class Controller implements TheObserver {
	private DialogEnum denum;
	public IDatabase db;
	private Logging logger;
	public SBMainFrame gui;
	private Zustand zustand;

	public Controller(SBMainFrame sb) {
		this.gui = sb;
		this.zustand = new Zustand();
	}

	/**loads Database and Logger
	 * @return true if properties are loaded correctly
	 */
	public boolean loadConfig() {
		Properties prop = new Properties();
		boolean retValue = true;
		try {
			// loading prop
			BufferedInputStream bis = new BufferedInputStream(this.getClass()
					.getResourceAsStream("sharebox.properties"));
			prop.load(bis);
			bis.close();
			if (System.getProperty("os.name").contains("win")) {
				logger = new Logging(prop.getProperty("logPathUnderWin"), "sharebox");
				db = new DatabaseJava(prop.getProperty("dbPathUnderWin"), logger);		
			} else {
				logger = new Logging(prop.getProperty("logPathUnderUnix"), "sharebox");
				db = new DatabaseJava(prop.getProperty("dbPathUnderUnix"), logger);	
			}
			
			// loading old database
			File serial = new File(prop.getProperty("dbPath"), "db.ser");
			if (serial.exists()) {
				db.loadDatabase();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			retValue = false;
		} catch (IOException e) {
			e.printStackTrace();
			retValue = false;
		}
		return retValue;
	}

	/**
	 * selector for Controlsettings
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.se2.sharebox.gui.TheObserver#update(com.se2.sharebox.gui.ObserverEnum
	 * )
	 */
	@Override
	public void update(ObserverEnum s) {
		switch (s) {
		case login:
			this.login();
			break;
		case listtokill:
			listToUninvite();
			break;
		case kill:
			uninvite();
			break;
		case invite:
			invite();
			break;
		case create:
			this.create();
			break;
		case upload:
			this.uploadFile();
			break;
		case delete:
			this.deleteFileOrFolder();
			break;
		case register:
			this.register();
			break;
		case showFiles:
			gui.setLogedIn(getTreePath());
			break;
		case showSettings:
			this.showSettings();
			break;
		case logout:
			this.logout();
			break;
		case changePw:
			this.changePass();
			break;
		case getSpace:
			this.getSpace();
			break;
		case delAcc:
			this.deleteAcc();
			break;
		case exit:
			this.close();
		case download:
			this.download();
			break;
		default:
			break;

		}
	}


	private boolean listToUninvite(){
		File file = new File(toPath(gui.getTreePath()));
		if (db.getBadFiles(zustand.getEmail()).containsKey(file)){
			gui.setInvitedList(db.getBadFiles(zustand.getEmail()).get(file).toArray());
		}
		return true;
	}

	private boolean uninvite(){
	
		File path=new File(toPath(gui.getTreePath()));
		String kill=gui.getDialogInput(); //getter f�r kill list fehlt
		HashMap<File,ArrayList<String>> badfiles =db.getBadFiles(zustand.getEmail());
		ArrayList<String> benutzer =badfiles.remove(path);
		benutzer.remove(kill);
		badfiles.put(path,benutzer);

		HashMap<String,ArrayList<File>> nicefiles=db.getNiceFiles(kill);
		ArrayList<File> freigaben=nicefiles.remove(kill);
		freigaben.remove(path);
		nicefiles.put(kill, freigaben);
				
		return true;
	}

	private boolean invite() {
		String otherUserMail = gui.getDialogInput();
		Object[] path=gui.getTreePath();
		boolean freigabe=path[1].toString().equalsIgnoreCase("freigabe");
		if (db.userExists(otherUserMail)& (!freigabe)){
			File file = new File(toPath(path));
			db.addNiceFiles(file, zustand.getEmail(), otherUserMail);
			db.addBadFiles(file, otherUserMail, zustand.getEmail());
		} else {
			gui.displayDialog(denum.error);
		}
		return true;
	}

	private boolean deleteFileOrFolder() {
		String mail = zustand.getEmail();
		String path = toPath(gui.getTreePath());
		boolean retVal = db.remove(mail, path);
		gui.setLogedIn(getTreePath());
		return retVal;
	}
	
	private boolean uploadFile() {
		File f = gui.getFile();
		String[] path = toPath(gui.getTreePath()).split(File.separator);
		boolean isFreigabe = false;
		String realPath = "";
		
		for (String partpath : path) {
			if (isFreigabe) {
				realPath += partpath;
				realPath += File.separatorChar;
			}
			if (partpath.equalsIgnoreCase("freigabe")) {
				isFreigabe = true;
			}
		}
		
		if (realPath.isEmpty()) {
			for (String s: path) {
				realPath += s;
				realPath += File.separatorChar;
			}
		}
		return db.addFile(zustand.getEmail(), f, realPath);
	}
	
	private boolean download() {
		File f = gui.getFile();
		String[] path = toPath(gui.getTreePath()).split(File.separator);
		
		boolean isFreigabe = false;
		String realPath = "";
		
		for (String partpath : path) {
			if (isFreigabe) {
				realPath += partpath;
				realPath += File.separatorChar;
			}
			if (partpath.equalsIgnoreCase("freigabe")) {
				isFreigabe = true;
			}
		}
		
		if (realPath.isEmpty()) {
			for (String s: path) {
				realPath += s;
				realPath += File.separatorChar;
			}
		}
		System.out.println("src:" + realPath);
		System.out.println("dest:" + f.getPath());
		return db.downloadFile(zustand.getEmail(), f, realPath);
	}
	
	public boolean changePass() {
		String oldPass = new String(gui.getCheckPw());
		String newPass = new String(gui.getNewPw());
		boolean retVal;
		if (db.equalsPass(zustand.getEmail(), oldPass) && !newPass.isEmpty()) {
			retVal = db.setPass(zustand.getEmail(), newPass);
			gui.setLogedIn(getTreePath());
		} else {
			gui.setLogedIn(getTreePath());
			retVal = false;
		}
		return retVal;
	}

	/**
	 * to rise your Space for cash
	 * @return true if successfully
	 */
	public boolean getSpace() {
		long newSpace = Integer.parseInt(gui.getSpace());
		boolean retVal = Zahlungssystem.zahlen((newSpace * 5), gui.getPayName(),
				gui.getKtnr(), gui.getBlz());
		long newSpaceInBytes = newSpace * 1024 * 1024 * 1024;
		db.increaseMaxSpace(zustand.getEmail(), newSpaceInBytes);
		if (!retVal) {
			gui.displayDialog(denum.error);
		}
		gui.setLogedIn(getTreePath());
		return retVal;
	}
	/**
	 * for deleting Accounts
	 * @return true if successfully
	 */
	public boolean deleteAcc() {
		String email = zustand.getEmail();
		String pass = new String(gui.getCheckPw());
		boolean retVal = db.equalsPass(email, pass);
		db.removeUser(email);
		this.logout();
		// TODO remove linked ressources
		return retVal;
	}

	/**
	 * Displays the settings in the GUI
	 * @return true if successfully
	 */
	public boolean showSettings() {
		String email = zustand.getEmail();
		long usedSpace = db.getUsedSpace(email);
		long maxSpace = db.getMaxSpace(email);
		Object[] state = { email, String.valueOf(byteToGig(usedSpace)),
				String.valueOf(byteToGig(maxSpace)) };
		gui.setSettings(state);
		return true;
	}

	public long byteToGig(long bytes) {
		return (bytes / (1024 * 1024 * 1024));
	}

	/**
	 * create a folder
	 * 
	 * @return true if folder created successfully
	 */
	public boolean create() {
		boolean retVal=false;
		String foldername = gui.getDialogInput();
		Object[] path=gui.getTreePath();
		int dd=path.length;
		if (dd>1)
			if (path[1].toString().equalsIgnoreCase("freigabe")){
			int ii;
			Object[] tmpPath=new Object[(dd-2)]; 
			for (ii=2;ii<dd;ii++){
				System.out.println(path[ii].toString());
				tmpPath[(ii-2)]=path[ii];
				System.out.println("best"+tmpPath[ii-2].toString());
			}
		}
		retVal = db.addFolder(toPath(path) + File.separatorChar
				+ foldername);
		gui.setLogedIn(getTreePath());
		return retVal;
	}

	/**
	 * User Logout: resets Zustand and saves Database
	 * 
	 * @return boolean
	 */
	public boolean logout() {
		boolean retVal;
		zustand.setEmail("");
		db.saveDatabase();
		retVal = gui.setLoggedOut();
		return retVal;
	}

	/**
	 * save Database and close Program
	 */
	private void close() {
		db.saveDatabase();
		gui.exitGUI();
	}
	
	/**
	 * to upload files
	 * @return true if successfully
	 */
	public boolean upload(){
		boolean retVal = db.addFile(zustand.getEmail(), gui.getFile(), this.toPath(gui.getTreePath()));
		gui.setLogedIn(getTreePath());
		return retVal;
	}
	
	/**
	 * register only new members and creates root folder
	 * 
	 * @return true if user doesn't exits
	 */
	public boolean register() {
		boolean retVal = false;
		String mail = gui.getLoginEmail();
		String pass = new String(gui.getLoginPw());
		if (!mail.isEmpty()) {
			retVal = db.createUser(mail, pass);
			System.out.println(retVal);
		}
		if (retVal) {
			zustand.setEmail(mail);
			gui.setLogedIn(getTreePath());
		} else {
			gui.displayDialog(denum.exists);
		}		
		return retVal;
	}

	/**
	 * 
	 * @return true if successfully
	 */
	public boolean login() {
		boolean retVal = false;
		String email = gui.getLoginEmail();
		String pass = new String(gui.getLoginPw());

		if (db.userExists(email)) {
			if (db.equalsPass(email, pass)) {
				zustand.setEmail(email);
				gui.setLogedIn(getTreePath());
				retVal = true;
			}
		}
		if (!retVal)
			gui.displayDialog(denum.wrong);
		return retVal;
	}

	public DefaultMutableTreeNode getTreePath() {
		File root = db.getRootView(zustand.getEmail());
		DefaultMutableTreeNode rootNode = myNode(root.getName(), true);
		buildTreeNode(root, rootNode);
		appendFreigaben(rootNode);
		return rootNode;
	}

	private DefaultMutableTreeNode appendFreigaben(DefaultMutableTreeNode node) {
		DefaultMutableTreeNode freigabe = myNode("Freigabe", true);
		node.add(freigabe);
		// ------------------------------------------------------
		File dbRoot = db.getRootView(zustand.getEmail()).getParentFile();
		HashMap<String, ArrayList<File>> niceFiles = db.getNiceFiles(zustand
				.getEmail());
		Iterator<String> itr = niceFiles.keySet().iterator();

		while (itr.hasNext()) {
			String user = itr.next();
			DefaultMutableTreeNode child = myNode(user, true);
			ArrayList<File> userFreigaben = niceFiles.get(user);

			for (File relativFile : userFreigaben) {

				File realFile = new File(dbRoot, relativFile.toString());
				DefaultMutableTreeNode realChild;
				if (realFile.isDirectory()) {
					realChild = myNode(realFile.getName(), true);
					buildTreeNode(realFile, realChild);
				} else {
					realChild = myNode(realFile.getName(), false);
				}
				child.add(realChild);
			}
			freigabe.add(child);
		}

		return node;
	}

	private void buildTreeNode(File root, DefaultMutableTreeNode node) {
		if (root.isDirectory()) {
			File[] children = root.listFiles();
			for (File child : children) {
				if (child.isFile()) {
					node.add(myNode(child.getName(), false));
				} else {
					DefaultMutableTreeNode childNode = myNode(child.getName(),
							true);
					node.add(childNode);
					buildTreeNode(child, childNode);
				}
			}
		}
	}

	public DefaultMutableTreeNode myNode(Object userObject, boolean bb) {
		if (bb)
			return new DefaultMutableTreeNode(userObject) {
				@Override
				public boolean isLeaf() {
					return false;
				}
			};
		else
			return new DefaultMutableTreeNode(userObject);
	}
	
	/**
	 * 
	 * @param obj
	 * @return String
	 */
	public String toPath(Object[] obj) {
		String tmpString = "";
		for (Object o : obj) {
			tmpString = tmpString + File.separatorChar + o.toString();
		}
		return tmpString;
	}
}
