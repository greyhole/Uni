package com.se2.sharebox.controller;

public interface IController {

}
