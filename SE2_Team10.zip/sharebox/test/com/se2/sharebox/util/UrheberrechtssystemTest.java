package com.se2.sharebox.util;

/**
 * BenachrichtigungssystemTest
 * 
 * 
 * @author SE_Team10
 * @version 1.0
 */
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;


public class UrheberrechtssystemTest {
	File file1, file2;
	@Before
	public void setUp() throws Exception {
		file1 = new File("Hallo.txt");
		file2 = new File("Inglorious Bastards");
	}

	@Test
	public void pruefeTest() {
		assertTrue(Urheberrechtssystem.pruefe(file1));
		assertTrue(!Urheberrechtssystem.pruefe(file2));
	}
}
