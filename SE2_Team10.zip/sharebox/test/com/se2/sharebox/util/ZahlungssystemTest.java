package com.se2.sharebox.util;

/**
 * ZahlungssystemTest
 * 
 * 
 * @author SE_Team10
 * @version 1.0
 */
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class ZahlungssystemTest {
	double betrag1, betrag2;
	String name1, name2, knr1, knr2, blz1, blz2;
	@Before
	public void setUp() throws Exception {
		betrag1 = 22.99;
		betrag2 = -12.99;
		name1="Max Musterman";
		name2="M4x Mu5t3rm4n";
		knr1="5121449151";
		knr2="51214491519";
		blz1="14040000";
		blz2="14043000";
	}

	@Test
	public void zahlenTest() {
		assertTrue(Zahlungssystem.zahlen(betrag1, name1, knr1, blz1));
		assertTrue(!Zahlungssystem.zahlen(betrag1, name1, knr1, blz2));
		assertTrue(!Zahlungssystem.zahlen(betrag1, name1, knr2, blz1));
		assertTrue(!Zahlungssystem.zahlen(betrag1, name2, knr1, blz1));
		assertTrue(!Zahlungssystem.zahlen(betrag2, name1, knr1, blz1));
	}

}
