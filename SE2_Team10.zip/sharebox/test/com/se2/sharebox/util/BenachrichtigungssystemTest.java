package com.se2.sharebox.util;

/**
 * BenachrichtigungssystemTest
 * 
 * 
 * @author SE_Team10
 * @version 1.0
 */
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class BenachrichtigungssystemTest {
	String mail, link, message;
	@Before
	public void setUp() throws Exception {
		//mail = "MaxMusterman@mailserver.de";
		mail = "";
		link = "HeinzHeine@mailserver.de/Freigabe/";
		message = "Wichtige Benachrichtigung!";
	}

	@Test
	public void sendMailTest() {
		assertTrue(Benachrichtigungssystem.sendEmail(mail,message));
	}
	@Test
	public void einladenTest() {
		assertTrue(Benachrichtigungssystem.einladen(mail,link));
	}
	@Test
	public void anmeldenTest() {
		assertTrue(Benachrichtigungssystem.anmelden(mail));
	}
}