package com.se2.sharebox.controller;

import static org.junit.Assert.*;

import java.awt.EventQueue;

import org.junit.Before;
import org.junit.Test;

import com.se2.sharebox.gui.SBMainFrame;

public class CaontrollerTest {
	
	
	SBMainFrame sb=new SBMainFrame();
	Controller contr = new Controller(sb);
	String name = "Tanja Lola";
	String mail = "bb";
	String pw = "b";
	String npw = "m";
	String ktnr = "2003472842";
	String blz = "12030000";
	
	@Before
	public void setUp() throws Exception {
		sb.loginEmailField.setText(mail);
		sb.loginPwField.setText(pw);
	}
	
	@Test
	public void testloadConfig() {
		assertTrue(contr.loadConfig());
	}	

	@Test
	public void testregister(){
		assertTrue(contr.register());
	}
	
	@Test
	public void testlogout(){
		assertTrue(contr.logout());
	}

	@Test
	public void testlogin() {
		sb.loginEmailField.setText(mail);
		sb.loginPwField.setText(pw);
		assertFalse(contr.login());
		contr.logout();
		
	}
	
	@Test
	public void testcreate(){
		sb.tmpString="a";
		assertTrue(contr.create());
	}
	
	@Test
	public void testshowSettings(){
		assertTrue(contr.showSettings());
	}
	@Test
	public void testgetSpace(){
		sb.nameField.setText(name);
		sb.spaceCombo.setSelectedIndex(0);
		sb.ktnrField.setText(ktnr);
		sb.blzField.setText(blz);
		assertTrue(contr.getSpace());
		assertEquals(contr.db.getMaxSpace(mail),3*1024*1024*1024);
	}
	@Test
	public void testchangePass(){
		sb.newPwField.setText(npw);
		sb.currentPwField.setText(pw);
		assertTrue(contr.changePass());
		contr.logout();
		assertTrue(contr.login());
	}
	@Test
	public void testdeleteAcc(){
		assertTrue(contr.deleteAcc());
		assertFalse(contr.login());
	}

}
