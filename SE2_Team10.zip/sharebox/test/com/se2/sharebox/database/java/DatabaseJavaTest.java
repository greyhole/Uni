package com.se2.sharebox.database.java;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Set;
import java.util.TreeSet;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class DatabaseJavaTest {

	private static DatabaseJava db;

	private static String path = "/tmp/db";

	@BeforeClass
	public static void setUp() throws Exception {
		db = new DatabaseJava(path);
		db.createUser("bb", "aol");
	}

	@AfterClass
	public static void tearDown() throws Exception {
		db.removeFolder("@oll", "");
		db.removeFolder("bb", "");
		db = null;

	}

	@Test
	public void createUserTest() {
		db.createUser("@oll", "bb");
		File expected = new File("/tmp/db/_oll");
		assertTrue(expected.exists());
	}

	@Test
	public void removeUserTest() {
		db.createUser("dd@dbd.dd", "dd");
		db.addFolder("mnt/g/dd");
		db.removeUser("dd@dbd.dd");
		assertFalse(new File("/tmp/dd_dbd.dd/mnt").exists());
	}

	@Test
	public void compareRightPass() {
		assertTrue(db.equalsPass("aol", "bb"));

	}

	@Test
	public void compareFalsePass() {
		assertFalse(db.equalsPass("aa", "bb"));
	}

	@Test
	public void addFileTest() {
		db.addFile("bb", new File("/tmp/1.jpg"), "mum");
		assertTrue(new File("/tmp/db/bb/mum/1.jpg").exists());
	}

	@Test
	public void addFolderTest() {
		db.addFolder("mnt/bb");
		File expected = new File(path, "bb/mnt/bb");
		assertTrue(expected.exists());
		expected.delete();
	}

	@Test
	public void removeFolder() {
		db.removeFolder("bb", "mnt/bb");
		File expected = new File(path, "bb/mnt/bb");
		assertFalse(expected.exists());
		expected.delete();
	}

	@Test
	public void removeFile() {
		db.addFile("bb", new File("/tmp/1.jpg"), "mum");
		db.remove("bb", "/mum/1.jpg");
		assertFalse(new File(path, "/bb/mum/1.jpg").exists());
	}

	@Test
	public void rootViewTest() {
		File actuals = db.getRootView("bb");
		File expecteds = new File("/tmp/db/bb");
		assertEquals(expecteds, actuals);
	}
	
//	@Test
//	public void loadSaveCycleTest() throws NoSuchFieldException {
//		db.saveDatabase();
//		DatabaseJava actual = new DatabaseJava(path);
//		actual.loadDatabase();
//		assertTrue(actual.("bb").getMail().equalsIgnoreCase("bb"));
//	}
}
