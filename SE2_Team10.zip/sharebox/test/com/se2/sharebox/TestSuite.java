package com.se2.sharebox;

/**
 * TestSuite
 * 
 * 
 * @author SE_Team10
 * @version 1.0
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//import com.se2.sharebox.controller.CaontrollerTest;
import com.se2.sharebox.util.BenachrichtigungssystemTest;
import com.se2.sharebox.util.UrheberrechtssystemTest;
import com.se2.sharebox.util.ZahlungssystemTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({BenachrichtigungssystemTest.class, UrheberrechtssystemTest.class, ZahlungssystemTest.class
//CoantrollerTest.class	
})
public class TestSuite {

}