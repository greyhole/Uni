/*
 * Paralleles Rechnen, Uebung 1
 * Matrix-Multiplikation nach Schulmethode 
 *
 * vim: expandtab shiftwidth=4 tabstop=4
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>

typedef struct {
    int rows, cols;
    float *data;
} matrix_t;

bool read_matrix(char *filepath, matrix_t* matrix)
{
    int i, j;
    FILE *f;

    if ((f = fopen(filepath, "r")) == NULL) {
        perror("Can't open file!");
        return false;
    }

    fscanf(f, "%d", &matrix->rows);
    fscanf(f, "%d", &matrix->cols);

    matrix->data = malloc(matrix->rows * matrix->cols * sizeof(*matrix->data));
    if (matrix->data == NULL) {
        return false;
    }

    for (i = 0; i < matrix->rows; ++i) {
        for (j = 0; j < matrix->cols; ++j) {
            fscanf(f, "%f\t", &matrix->data[matrix->cols * i + j]);
        }
        fscanf(f, "\n");
    }

    fclose(f);

    return true;
}

double sum_matrix(matrix_t* m)
{
    int i;
    double retval = 0;

    for (i = 0; i < m->rows * m->cols; i++) {
        retval = retval + m->data[i];
    }

    return retval;
}


void print_matrix(matrix_t* m)
{
    int i, j;

    for (i = 0; i < m->rows; i++) {
        for (j = 0; j < m->cols; j++) {
            printf("%.2f\t ", m->data[i * m->cols + j]);
        }
        printf("\n");
    }

    printf("sum: %.2f\n", sum_matrix(m));
}

void matrix_mult(matrix_t* a, matrix_t* b, matrix_t* r)
{
    long row, col, i;
    float tmp;

#ifdef CACHE_AWARE
#endif

    for (row = 0; row < r->rows; row++) {
        for (col = 0; col < r->cols; col++) {
            tmp = 0;
            for (i = 0; i < a->cols; i++) {
                tmp += a->data[row * a->cols + i] * b->data[i * b->cols + col];
            }   
            r->data[row * r->cols + col] = tmp;            
        }
    }
}

int main(int argc, char* argv[])
{
    matrix_t input_a = { 0, 0, NULL };
    matrix_t input_b = input_a;
    matrix_t result = input_a;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <file1> <file2>\n", argv[0]);
        return EXIT_FAILURE;
    }

    if (!read_matrix(argv[1], &input_a)) {
        fputs("could not read input matrix A", stderr);
        return EXIT_FAILURE;
    }
    if (!read_matrix(argv[2], &input_b)) {
        fputs("could not read input matrix B", stderr);
        return EXIT_FAILURE;
    }

    result.rows = input_a.rows;
    result.cols = input_b.cols;
    result.data = calloc(result.rows * result.cols, sizeof(*result.data));
    if (result.data == NULL) {
        perror("calloc for result");
        return EXIT_FAILURE;
    }

    matrix_mult(&input_a, &input_b, &result);
    print_matrix(&result);

    free(input_a.data);
    free(input_b.data);
    free(result.data);

    return EXIT_SUCCESS;
}

